﻿namespace ECommerce.Web.DTOs;

public class RefreshTokenRequestDto
{
    public string RefreshToken { get; set; } = string.Empty;
}